import Cart from "./Cart";
import { screen,render } from "@testing-library/react";

test("Checking shopping cart text ", () => {
    render(<Cart/>);
    const shoppingTest = screen.getByText(/'Your Shopping Cart'/i);
    expect(shoppingTest).toBeInTheDocument();
})
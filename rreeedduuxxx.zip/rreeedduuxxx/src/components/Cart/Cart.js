import { useSelector } from 'react-redux';
import Card from '../UI/Card';
import classes from './Cart.module.css';
import CartItem from './CartItem';

const Cart = (props) => {
  const isCartVisible = useSelector( state => state.cartData.isCartVisible);
  const cartProducts = useSelector( state => state.cartData.cartItems);
  // console.log(cartProducts);
  let totalAmount = 0;
  
  
  return (

    <>
     {isCartVisible && <Card className={classes.cart}>
      <h2>Your Shopping Cart</h2>
      <ul>
        {cartProducts.map( (val) => 
       <CartItem
        item={{ title: val.title,
           quantity: val.quantity,
            total: val.quantity*val.price, price: val.price ,
             id: val.id}}/>
            )
            }
      </ul>
    </Card>}
    </>
  );
};

export default Cart;

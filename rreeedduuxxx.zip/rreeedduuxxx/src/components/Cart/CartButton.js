import { useDispatch, useSelector } from 'react-redux';
import classes from './CartButton.module.css';
import { cartAction } from '../../store/carySlice';

const CartButton = (props) => {
  const dispatch = useDispatch();

  const cartVisibilityhandler = () => {
      dispatch( cartAction.cartVisibilityHandler())
  }
  const totalCartItmes =  useSelector( state => state.cartData.cartItems); 
 
  return (
    <button className={classes.button} onClick={ cartVisibilityhandler }>
      <span>My Cart</span>
      <span className={classes.badge}>{totalCartItmes.length}</span>
    </button>
  );
};

export default CartButton;

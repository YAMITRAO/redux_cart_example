import React from 'react'
import style from "./Apiframe.module.css"

const Apiframe = (props) => {
    

  return (
    <>
    { (props.data === "sending") && <div className={ style.sending}>{props.data}...</div> }
    { (props.data === "error") && <div className={ style.error}>{props.data}</div> }
    { (props.data === "success") && <div className={ style.success}>{props.data}</div> }
    </>
    
  )
}

export default Apiframe
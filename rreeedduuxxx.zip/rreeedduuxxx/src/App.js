import { useDispatch, useSelector } from 'react-redux';
import Cart from './components/Cart/Cart';
import Layout from './components/Layout/Layout';
import Products from './components/Shop/Products';
import { useEffect, useState } from 'react';
import { cartAction } from './store/carySlice';
import Apiframe from './components/Layout/Apiframe';

function App() {
  const cartChange = useSelector(state => state.cartData.cartItems);
  console.log(cartChange);
  const dispatch = useDispatch();

  const [sending, setsending] = useState("");

  const putApi = async() => {
    // try{
      // setsending("sending");
      const response =  fetch("https://moviereactapp-3a393-default-rtdb.asia-southeast1.firebasedatabase.app/cart.json",{
      method:'PUT',
      body:JSON.stringify({
        data : cartChange
      }
      ),
      headers:{
        'Content-type':"application/json"
      }
    })
   
    
  }

  const getApi = async() => {
    setsending("sending")
    try{
      const response = await fetch("https://moviereactapp-3a393-default-rtdb.asia-southeast1.firebasedatabase.app/cart.json");
      if(!response.ok){
        const data = await response.json();
        throw new Error(data.error.message);
      }
      const data = await response.json()
      console.log(data);
      setsending("success")
      dispatch(cartAction.cartgetApi(data.data))
    }
    catch(error){
      console.log("GET_REQUEST_ERROR", error);
      setsending("error")
    } 
    setTimeout( ()=> {setsending("")}, 1000)
  }
useEffect(() => {
  getApi();
}, []);
  
   
  useEffect( ()=> {
    putApi();
  }, [cartChange])
  return (
    <>
     {sending && <Apiframe data ={sending}  />}
    <Layout>
      <Cart />
      <Products />
    </Layout>
    </>
  );
}

export default App;

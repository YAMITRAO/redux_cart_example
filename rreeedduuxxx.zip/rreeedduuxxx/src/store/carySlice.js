

import { createSlice } from "@reduxjs/toolkit";


const initialCartState = {
    isCartVisible: false,
    cartItems : [],
}

const cartSlice = createSlice( {
    name:"cartReducer",
    initialState:initialCartState,
    reducers: {
        cartVisibilityHandler(state){
            state.isCartVisible = !state.isCartVisible
        },
        cartgetApi(state, action){
            state.cartItems = action.payload
        },
        cartItemHandler(state, action){
            console.log(action.payload);
            console.log(state.cartItems);
            if(!state.cartItems.length){
                state.cartItems.push(
                    action.payload
                );
            }
            else{
                let id_product = action.payload.id;
                let flag_to_add = true;
                state.cartItems.forEach( (val) => {
                   if(val.id === id_product){
                    val.quantity +=1
                    flag_to_add = false;
                    return;
                   } 
                  
               
                }
                );
                if(flag_to_add){
                    state.cartItems.push(
                        action.payload
                    )
                }
                    
            }
        },
        cartItemRemove(state,action){
            let remove_id = action.payload;
            state.cartItems.forEach((val, index) => {
                if(val.id === remove_id){
                    if(val.quantity == 1){
                        state.cartItems.splice(index,1);
                    }
                    else{
                        val.quantity -= 1;
                    }
                    
                    return
                }
            })
        }
    }
})

export const cartAction = cartSlice.actions;
export default cartSlice.reducer;
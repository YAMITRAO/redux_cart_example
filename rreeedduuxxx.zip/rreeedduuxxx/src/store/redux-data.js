import { configureStore } from "@reduxjs/toolkit";
import cartSlice from "./carySlice";


const storeData = configureStore({
    reducer: {
        cartData : cartSlice
    }  
});


export default storeData;
import logo from './logo.svg';
import './App.css';
import Project from './Component/Project';

function App() {
  return (
    <>
    <h1>Hello</h1>
    <Project/>
    </>
    
  );
}

export default App;

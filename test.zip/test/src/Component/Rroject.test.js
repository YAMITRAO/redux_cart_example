import { render, screen } from '@testing-library/react';
import Project from './Project';
import userEvent from "@testing-library/user-event";


describe('Project app', () => {
    test('Test to ckeck render para before click', () => {
        render(<Project/>)
        const beforeClick = screen.getByText('My Para before click', {exact: false});
        expect(beforeClick).toBeInTheDocument();
    });

    test('Test to ckeck render para after click', () => {
        render(<Project/>)
        
        const buttonElement = screen.getByRole('button');
        userEvent.click(buttonElement);

        const afterClick = screen.getByText('My para after click');
        expect(afterClick).toBeInTheDocument();
    });



})

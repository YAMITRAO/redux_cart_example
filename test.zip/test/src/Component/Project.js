import React, { useState } from 'react'

const Project = () => {
  const [isClicked, setIsClicked] = useState(false);
   const clickHandler = () => {
    setIsClicked(true);
   }
  return (
    <div>
        {!isClicked && <p>My Para before click</p>}
        {isClicked && <p>My para after click</p>}
        <button onClick={ clickHandler }>Click</button>
    </div>
  )
}

export default Project